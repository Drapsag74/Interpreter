/* 
 * File:   InterpreteurException.cpp
 * Author: martin
 * 
 * Created on 7 décembre 2014, 19:08
 */

#include "Exceptions.h"

